import os

ROOT_PATH = os.path.normpath(os.path.join(__file__, '../../')) + "/"
DATA_DIR_PATH = ROOT_PATH + "data/"

WINDOW_SIZE_X = 1440
WINDOW_SIZE_Y = 960