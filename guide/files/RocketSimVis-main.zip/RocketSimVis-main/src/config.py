class ConfigVal:
    def __init__(self, default, min, max):
        self.val = float(default)
        self.min = float(min)
        self.max = float(max)

    def __float__(self):
        return self.val

class Config:
    def __init__(self):
        self.camera_distance = ConfigVal(300, 100, 500)
        self.camera_height = ConfigVal(120, 0, 300)
        self.camera_fov = ConfigVal(90, 20, 120)
        self.camera_bird_fov = ConfigVal(60, 20, 120)

        self.camera_lean_height_scale = ConfigVal(1.0, 0, 1)
        self.camera_lean_dist_scale = ConfigVal(0.1, 0, 1)
        self.camera_lean_min_height_clamp = ConfigVal(300, 0, 500)

        self.ball_prediction_enabled = False
        self.ball_prediction_seconds = ConfigVal(2.0, 0.2, 10.0)
        self.ball_prediction_color_rgb = [242, 217, 64]

        self.enable_team_tint = False
        self.team_blue_color_rgb = [165, 104, 154]
        self.team_orange_color_rgb = [119, 168, 112]

        self.enable_boost_colors = False
        self.boost_trail_color_rgb = [255, 230, 102]
        self.boost_pad_color_rgb = [255, 230, 102]
        self.show_timesteps_in_hud = False

    def reset_camera_defaults(self):
        self.camera_distance.val = 300.0
        self.camera_height.val = 120.0
        self.camera_fov.val = 90.0
        self.camera_bird_fov.val = 60.0
        self.camera_lean_height_scale.val = 1.0
        self.camera_lean_dist_scale.val = 0.1
        self.camera_lean_min_height_clamp.val = 300.0

    def reset_ball_prediction_defaults(self):
        self.ball_prediction_enabled = False
        self.ball_prediction_seconds.val = 2.0
        self.ball_prediction_color_rgb = [242, 217, 64]
