from pathlib import Path
import sys
import time
import time

from PyQt5 import QtWidgets
from PyQt5.QtCore import Qt, QTimer
from PyQt5.Qt import QWidget, pyqtSlot, QEvent
from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import QSizePolicy, QStackedLayout

from config import Config, ConfigVal
from const import WINDOW_SIZE_X, WINDOW_SIZE_Y

_g_ui_widget = None
_g_scaling_factor = 1.0


def update_scaling_factor(app: QtWidgets.QApplication):
    global _g_scaling_factor
    screen = app.primaryScreen()
    if screen:
        # Stable scaling derived from logical DPI instead of font heuristics.
        _g_scaling_factor = max(0.85, min(2.0, screen.logicalDotsPerInch() / 96.0))
    else:
        _g_scaling_factor = 1.0


def get_scaling_factor():
    return _g_scaling_factor


class QConfigVal(QWidget):
    FLOAT_SLIDER_PREC = 1000

    def __init__(self, name: str, config_val: ConfigVal):
        super().__init__()

        self.name = name
        self.config_val = config_val
        self.float_mode = (config_val.max - config_val.min) < 10

        self.setObjectName("ConfigRow")
        self.setAttribute(Qt.WA_StyledBackground)

        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(6, 3, 6, 3)
        layout.setSpacing(6)

        self.label = QtWidgets.QLabel(self.get_beautified_name())
        self.label.setObjectName("ConfigLabel")
        self.label.setMinimumWidth(210)

        self.value_label = QtWidgets.QLabel("0")
        self.value_label.setObjectName("ConfigValue")
        self.value_label.setMinimumWidth(48)
        self.value_label.setAlignment(Qt.AlignCenter)

        self.slider = QtWidgets.QSlider(Qt.Horizontal, self)
        self.slider.setObjectName("ConfigSlider")
        self.slider.setMinimumWidth(220)
        self.slider.setFocusPolicy(Qt.NoFocus)

        if self.float_mode:
            self.slider.setRange(0, self.FLOAT_SLIDER_PREC)
            val_frac = (config_val.val - config_val.min) / max(config_val.max - config_val.min, 1e-7)
            self.slider.setValue(round(val_frac * self.FLOAT_SLIDER_PREC))
        else:
            self.slider.setRange(round(config_val.min), round(config_val.max))
            self.slider.setValue(round(config_val.val))

        self.slider.valueChanged.connect(self.on_val_changed)

        layout.addWidget(self.value_label)
        layout.addWidget(self.slider, 1)
        layout.addWidget(self.label)

        self.on_val_changed()

    def get_beautified_name(self):
        name_map = {
            "camera_distance": "Distance",
            "camera_height": "Height",
            "camera_fov": "FOV",
            "camera_bird_fov": "Bird FOV",
            "camera_lean_height_scale": "Lean Height Scale",
            "camera_lean_dist_scale": "Lean Distance Scale",
            "camera_lean_min_height_clamp": "Lean Minimum Height Scale",
            "ball_prediction_seconds": "Future Seconds",
        }
        if self.name in name_map:
            return name_map[self.name]
        return self.name.replace("camera_", "").replace("_", " ").title()

    @pyqtSlot()
    def on_val_changed(self):
        if self.float_mode:
            slider_frac = self.slider.value() / self.FLOAT_SLIDER_PREC
            self.config_val.val = self.config_val.min + (self.config_val.max - self.config_val.min) * slider_frac
            value_txt = f"{self.config_val.val:.2f}"
        else:
            self.config_val.val = self.slider.value()
            value_txt = str(int(round(self.config_val.val)))

        self.value_label.setText(value_txt)

    def sync_from_config(self):
        if self.float_mode:
            val_frac = (self.config_val.val - self.config_val.min) / max(self.config_val.max - self.config_val.min, 1e-7)
            slider_val = round(val_frac * self.FLOAT_SLIDER_PREC)
        else:
            slider_val = round(self.config_val.val)
        if self.slider.value() != slider_val:
            self.slider.blockSignals(True)
            self.slider.setValue(slider_val)
            self.slider.blockSignals(False)
        self.on_val_changed()


class QConfigCheck(QWidget):
    def __init__(self, name: str, config: Config, attr_name: str):
        super().__init__()
        self._config = config
        self._attr_name = attr_name

        self.setObjectName("ConfigRow")
        self.setAttribute(Qt.WA_StyledBackground)

        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(6, 3, 6, 3)
        layout.setSpacing(6)

        self.checkbox = QtWidgets.QCheckBox(name)
        self.checkbox.setChecked(bool(getattr(self._config, self._attr_name)))
        self.checkbox.toggled.connect(self.on_toggled)
        layout.addWidget(self.checkbox)
        layout.addStretch(1)

    @pyqtSlot(bool)
    def on_toggled(self, checked: bool):
        setattr(self._config, self._attr_name, bool(checked))

    def sync_from_config(self):
        desired = bool(getattr(self._config, self._attr_name))
        if self.checkbox.isChecked() != desired:
            self.checkbox.blockSignals(True)
            self.checkbox.setChecked(desired)
            self.checkbox.blockSignals(False)


class QColorPickerRow(QWidget):
    def __init__(self, name: str, config: Config, attr_name: str):
        super().__init__()
        self._config = config
        self._attr_name = attr_name
        self._label_name = name

        self.setObjectName("ConfigRow")
        self.setAttribute(Qt.WA_StyledBackground)

        layout = QtWidgets.QHBoxLayout(self)
        layout.setContentsMargins(6, 3, 6, 3)
        layout.setSpacing(6)

        label = QtWidgets.QLabel(name)
        label.setObjectName("ConfigLabel")
        label.setMinimumWidth(210)
        layout.addWidget(label)

        self.button = QtWidgets.QPushButton("Pick Color")
        self.button.clicked.connect(self.on_pick_color)
        layout.addWidget(self.button)

        self.swatch = QtWidgets.QLabel()
        self.swatch.setObjectName("ColorSwatch")
        self.swatch.setFixedSize(42, 18)
        layout.addWidget(self.swatch)
        layout.addStretch(1)

        self._sync_swatch()

    def _sync_swatch(self):
        rgb = getattr(self._config, self._attr_name)
        r, g, b = int(rgb[0]), int(rgb[1]), int(rgb[2])
        self.swatch.setStyleSheet(
            f"background-color: rgb({r}, {g}, {b}); border: 1px solid rgba(222, 188, 52, 0.75); border-radius: 3px;"
        )

    def sync_from_config(self):
        self._sync_swatch()

    @pyqtSlot()
    def on_pick_color(self):
        rgb = getattr(self._config, self._attr_name)
        initial = QColor(int(rgb[0]), int(rgb[1]), int(rgb[2]))
        color = QtWidgets.QColorDialog.getColor(initial, self, f"Select {self._label_name}")
        if color.isValid():
            setattr(self._config, self._attr_name, [color.red(), color.green(), color.blue()])
            self._sync_swatch()


class QEditConfigWidget(QWidget):
    def __init__(self, config: Config, parent_window):
        super().__init__()
        self.parent_window = parent_window

        self.setObjectName("EditConfigContainer")
        self.setAttribute(Qt.WA_StyledBackground)
        self.setAutoFillBackground(True)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(7, 7, 7, 7)
        layout.setSpacing(4)

        header = QtWidgets.QLabel("Settings")
        header.setObjectName("PanelTitle")
        layout.addWidget(header)

        tab_bar = QtWidgets.QFrame()
        tab_bar.setObjectName("TabBar")
        tab_layout = QtWidgets.QHBoxLayout(tab_bar)
        tab_layout.setContentsMargins(3, 2, 3, 2)
        tab_layout.setSpacing(5)
        self.tab_buttons = []
        self.tab_to_idx = {}
        for tab_name in ["Home", "Settings", "Visuals", "Ball Prediction", "Keybinds"]:
            btn = QtWidgets.QPushButton(tab_name)
            btn.setObjectName("TabButton")
            btn.setCheckable(True)
            btn.setAutoExclusive(True)
            if tab_name == "Home":
                btn.setChecked(True)
            btn.toggled.connect(lambda checked, n=tab_name: self.on_tab_toggled(n, checked))
            self.tab_buttons.append(btn)
            tab_layout.addWidget(btn)
        tab_layout.addStretch(1)
        layout.addWidget(tab_bar)

        self.pages = QtWidgets.QStackedWidget()
        self.pages.setObjectName("Pages")
        self.pages.setAttribute(Qt.WA_StyledBackground)
        self.pages.setAutoFillBackground(True)
        self.pages.layout().setStackingMode(QStackedLayout.StackOne)

        self.config = config

        settings_page = QWidget()
        settings_page.setObjectName("TabPage")
        settings_page.setAttribute(Qt.WA_StyledBackground)
        settings_page.setAutoFillBackground(True)
        settings_page_layout = QtWidgets.QVBoxLayout(settings_page)
        settings_page_layout.setContentsMargins(0, 0, 0, 0)
        settings_page_layout.setSpacing(0)
        settings_scroll = QtWidgets.QScrollArea()
        settings_scroll.setWidgetResizable(True)
        settings_scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        settings_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        settings_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        settings_page_layout.addWidget(settings_scroll)
        settings_content = QWidget()
        settings_content.setObjectName("TabPage")
        settings_content.setAttribute(Qt.WA_StyledBackground)
        settings_content.setAutoFillBackground(True)
        settings_layout = QtWidgets.QVBoxLayout(settings_content)
        settings_layout.setContentsMargins(0, 0, 0, 0)
        settings_layout.setSpacing(4)
        for name, obj in self.config.__dict__.items():
            if isinstance(obj, ConfigVal) and name.startswith("camera_"):
                settings_layout.addWidget(QConfigVal(name, obj))
        self.camera_defaults_btn = QtWidgets.QPushButton("Set Camera To Default")
        self.camera_defaults_btn.clicked.connect(self.parent_window.reset_camera_settings_to_default)
        settings_layout.addWidget(self.camera_defaults_btn)
        settings_layout.addStretch(1)
        settings_scroll.setWidget(settings_content)
        self.tab_to_idx["Settings"] = self.pages.addWidget(settings_page)

        ball_page = QWidget()
        ball_page.setObjectName("TabPage")
        ball_page.setAttribute(Qt.WA_StyledBackground)
        ball_page.setAutoFillBackground(True)
        ball_layout = QtWidgets.QVBoxLayout(ball_page)
        ball_layout.setContentsMargins(0, 0, 0, 0)
        ball_layout.setSpacing(4)
        self.ball_prediction_enable_row = QConfigCheck("Enable Ball Prediction", self.config, "ball_prediction_enabled")
        self.ball_prediction_seconds_row = QConfigVal("ball_prediction_seconds", self.config.ball_prediction_seconds)
        self.ball_prediction_color_row = QColorPickerRow("Prediction Color", self.config, "ball_prediction_color_rgb")
        ball_layout.addWidget(self.ball_prediction_enable_row)
        ball_layout.addWidget(self.ball_prediction_seconds_row)
        ball_layout.addWidget(self.ball_prediction_color_row)
        self.ball_prediction_defaults_btn = QtWidgets.QPushButton("Set Prediction To Default")
        self.ball_prediction_defaults_btn.clicked.connect(self.parent_window.reset_ball_prediction_to_default)
        ball_layout.addWidget(self.ball_prediction_defaults_btn)
        ball_layout.addStretch(1)
        self.tab_to_idx["Ball Prediction"] = self.pages.addWidget(ball_page)

        visuals_page = QWidget()
        visuals_page.setObjectName("TabPage")
        visuals_page.setAttribute(Qt.WA_StyledBackground)
        visuals_page.setAutoFillBackground(True)
        visuals_layout = QtWidgets.QVBoxLayout(visuals_page)
        visuals_layout.setContentsMargins(0, 0, 0, 0)
        visuals_layout.setSpacing(4)
        visuals_layout.addWidget(QConfigCheck("Enable Team Tint", self.config, "enable_team_tint"))
        self.visuals_blue_row = QColorPickerRow("Blue Team Color", self.config, "team_blue_color_rgb")
        self.visuals_orange_row = QColorPickerRow("Orange Team Color", self.config, "team_orange_color_rgb")
        visuals_layout.addWidget(self.visuals_blue_row)
        visuals_layout.addWidget(self.visuals_orange_row)
        boost_section = QtWidgets.QFrame()
        boost_section.setObjectName("SnapshotCard")
        boost_layout = QtWidgets.QVBoxLayout(boost_section)
        boost_layout.setContentsMargins(7, 6, 7, 6)
        boost_layout.setSpacing(4)
        boost_title = QtWidgets.QLabel("Boost Colors")
        boost_title.setObjectName("SectionTitle")
        boost_layout.addWidget(boost_title)
        boost_layout.addWidget(QConfigCheck("Enable Boost Colors", self.config, "enable_boost_colors"))
        self.visuals_boost_trail_row = QColorPickerRow("Car Boost Trail Color", self.config, "boost_trail_color_rgb")
        self.visuals_boost_pad_row = QColorPickerRow("Map Boost Pad Color", self.config, "boost_pad_color_rgb")
        boost_layout.addWidget(self.visuals_boost_trail_row)
        boost_layout.addWidget(self.visuals_boost_pad_row)
        visuals_layout.addSpacing(8)
        visuals_layout.addWidget(boost_section)
        self.visuals_reset_btn = QtWidgets.QPushButton("Set All To Default")
        self.visuals_reset_btn.clicked.connect(self.parent_window.reset_visuals_to_default)
        visuals_layout.addWidget(self.visuals_reset_btn)
        visuals_layout.addStretch(1)
        self.tab_to_idx["Visuals"] = self.pages.addWidget(visuals_page)

        home_page = QWidget()
        home_page.setObjectName("TabPage")
        home_page.setAttribute(Qt.WA_StyledBackground)
        home_page.setAutoFillBackground(True)
        home_layout = QtWidgets.QVBoxLayout(home_page)
        home_layout.setContentsMargins(0, 0, 0, 0)
        home_layout.setSpacing(6)

        snapshot_card = QtWidgets.QFrame()
        snapshot_card.setObjectName("SnapshotCard")
        snapshot_layout = QtWidgets.QVBoxLayout(snapshot_card)
        snapshot_layout.setContentsMargins(7, 6, 7, 6)
        snapshot_layout.setSpacing(3)
        snapshot_title = QtWidgets.QLabel("Camera Snapshot")
        snapshot_title.setObjectName("SectionTitle")
        snapshot_layout.addWidget(snapshot_title)

        self.home_mode_label = QtWidgets.QLabel("Current Mode: Manual")
        self.home_mode_label.setObjectName("ConfigLabel")
        snapshot_layout.addWidget(self.home_mode_label)
        self.home_player_label = QtWidgets.QLabel("Spectating: None")
        self.home_player_label.setObjectName("ConfigLabel")
        snapshot_layout.addWidget(self.home_player_label)
        self.home_team_label = QtWidgets.QLabel("Team: N/A")
        self.home_team_label.setObjectName("ConfigLabel")
        snapshot_layout.addWidget(self.home_team_label)
        home_layout.addWidget(snapshot_card)

        auto_cycle_row = QWidget()
        auto_cycle_layout = QtWidgets.QHBoxLayout(auto_cycle_row)
        auto_cycle_layout.setContentsMargins(10, 0, 0, 0)
        auto_cycle_layout.setSpacing(0)
        self.home_auto_cycle_checkbox = QtWidgets.QCheckBox("Auto Cycle")
        self.home_auto_cycle_checkbox.toggled.connect(self.parent_window.set_auto_cycle_from_ui)
        auto_cycle_layout.addWidget(self.home_auto_cycle_checkbox)
        auto_cycle_layout.addStretch(1)
        home_layout.addWidget(auto_cycle_row)

        hud_timesteps_row = QWidget()
        hud_timesteps_layout = QtWidgets.QHBoxLayout(hud_timesteps_row)
        hud_timesteps_layout.setContentsMargins(10, 0, 0, 0)
        hud_timesteps_layout.setSpacing(0)
        self.home_show_timesteps_checkbox = QtWidgets.QCheckBox("Show Checkpoints In HUD")
        self.home_show_timesteps_checkbox.setChecked(bool(self.config.show_timesteps_in_hud))
        self.home_show_timesteps_checkbox.toggled.connect(self.parent_window.set_show_timesteps_in_hud)
        hud_timesteps_layout.addWidget(self.home_show_timesteps_checkbox)
        hud_timesteps_layout.addStretch(1)
        home_layout.addWidget(hud_timesteps_row)

        reset_btn = QtWidgets.QPushButton("Reset Camera")
        reset_btn.clicked.connect(self.parent_window.reset_camera_from_ui)
        home_layout.addWidget(reset_btn)
        refresh_btn = QtWidgets.QPushButton("Refresh UI")
        refresh_btn.clicked.connect(self.parent_window.refresh_ui_from_home)
        home_layout.addWidget(refresh_btn)
        home_layout.addStretch(1)
        about_card = QtWidgets.QFrame()
        about_card.setObjectName("AboutCard")
        about_layout = QtWidgets.QVBoxLayout(about_card)
        about_layout.setContentsMargins(7, 5, 7, 5)
        about_layout.setSpacing(2)
        about_title = QtWidgets.QLabel("Credits")
        about_title.setObjectName("SectionTitle")
        about_layout.addWidget(about_title)
        credit1 = QtWidgets.QLabel("ZealanL - Creator of RocketSimVis")
        credit1.setObjectName("AboutText")
        about_layout.addWidget(credit1)
        credit2 = QtWidgets.QLabel("Corresation - Revamped RocketSimVis")
        credit2.setObjectName("AboutText")
        about_layout.addWidget(credit2)
        home_layout.addWidget(about_card)
        self.tab_to_idx["Home"] = self.pages.addWidget(home_page)

        keybinds_page = QWidget()
        keybinds_page.setObjectName("TabPage")
        keybinds_page.setAttribute(Qt.WA_StyledBackground)
        keybinds_page.setAutoFillBackground(True)
        kb_layout = QtWidgets.QVBoxLayout(keybinds_page)
        kb_layout.setContentsMargins(0, 0, 0, 0)
        kb_layout.setSpacing(6)

        kb_title = QtWidgets.QLabel("Keybinds")
        kb_title.setObjectName("SectionTitle")
        kb_layout.addWidget(kb_title)

        kb_card = QtWidgets.QFrame()
        kb_card.setObjectName("SnapshotCard")
        kb_card_layout = QtWidgets.QVBoxLayout(kb_card)
        kb_card_layout.setContentsMargins(7, 6, 7, 6)
        kb_card_layout.setSpacing(2)

        keybind_lines = [
            "F1: Manual Camera",
            "F2: Auto-Focus Camera",
            "F3: Free Camera",
            "W / A / S / D: Move Free Camera",
            "Space: Move Up (Free Camera)",
            "Ctrl: Move Down (Free Camera)",
            "Mouse Move: Look Around (Free Camera, while tabbed in)",
            "Mouse Wheel: Zoom In / Out (Free Camera)",
            "R: Reset Free Camera Position",
            "Shift + Left Click: Cycle Spectate Target (Manual)",
            "P: Spectate Closest Player to Ball (Manual)",
            "F11: Toggle Fullscreen",
            "Esc: Exit Free Camera to Manual",
        ]
        for line in keybind_lines:
            lbl = QtWidgets.QLabel(line)
            lbl.setObjectName("ConfigLabel")
            kb_card_layout.addWidget(lbl)

        kb_layout.addWidget(kb_card)
        kb_layout.addStretch(1)
        self.tab_to_idx["Keybinds"] = self.pages.addWidget(keybinds_page)

        self.pages.setCurrentIndex(self.tab_to_idx["Home"])
        layout.addWidget(self.pages)

    def on_tab_toggled(self, tab_name: str, checked: bool):
        if not checked:
            return
        idx = self.tab_to_idx.get(tab_name)
        if idx is not None:
            self.pages.setCurrentIndex(idx)

    def set_home_snapshot(self, snapshot: dict):
        self.home_mode_label.setText(f"Current Mode: {snapshot.get('mode', 'Unknown')}")
        self.home_player_label.setText(f"Spectating: {snapshot.get('player', 'None')}")
        self.home_team_label.setText(f"Team: {snapshot.get('team', 'N/A')}")
        desired = bool(snapshot.get("auto_cycle", False))
        if self.home_auto_cycle_checkbox.isChecked() != desired:
            self.home_auto_cycle_checkbox.blockSignals(True)
            self.home_auto_cycle_checkbox.setChecked(desired)
            self.home_auto_cycle_checkbox.blockSignals(False)
        desired_timesteps = bool(self.config.show_timesteps_in_hud)
        if self.home_show_timesteps_checkbox.isChecked() != desired_timesteps:
            self.home_show_timesteps_checkbox.blockSignals(True)
            self.home_show_timesteps_checkbox.setChecked(desired_timesteps)
            self.home_show_timesteps_checkbox.blockSignals(False)

    def refresh_visuals_color_rows(self):
        for cfg_val in self.findChildren(QConfigVal):
            cfg_val.sync_from_config()
        if hasattr(self, "visuals_blue_row"):
            self.visuals_blue_row._sync_swatch()
        if hasattr(self, "visuals_orange_row"):
            self.visuals_orange_row._sync_swatch()
        if hasattr(self, "visuals_boost_trail_row"):
            self.visuals_boost_trail_row._sync_swatch()
        if hasattr(self, "visuals_boost_pad_row"):
            self.visuals_boost_pad_row._sync_swatch()
        if hasattr(self, "ball_prediction_color_row"):
            self.ball_prediction_color_row.sync_from_config()
        for check in self.findChildren(QConfigCheck):
            check.sync_from_config()


class QUIBarWidget(QWidget):
    def __init__(self, parent_window):
        super().__init__()
        self.parent_window = parent_window

        self.setObjectName("HudContainer")
        self.setAttribute(Qt.WA_StyledBackground)
        self.setAutoFillBackground(True)

        vbox = QtWidgets.QVBoxLayout(self)
        vbox.setContentsMargins(8, 8, 8, 8)
        vbox.setSpacing(5)

        self.text_label = QtWidgets.QLabel("...")
        self.text_label.setWordWrap(True)
        self.text_label.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        self.text_label.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Minimum)
        self.text_label.setObjectName("HudText")
        vbox.addWidget(self.text_label)

        self.edit_config_button = QtWidgets.QPushButton("Edit Settings")
        self.edit_config_button.clicked.connect(self.on_edit_config)
        self.edit_config_button.setAutoDefault(False)
        self.edit_config_button.setDefault(False)
        self.edit_config_button.setFocusPolicy(Qt.NoFocus)
        self.edit_config_button.setObjectName("PrimaryButton")
        vbox.addWidget(self.edit_config_button)

        global _g_ui_widget
        _g_ui_widget = self

    @pyqtSlot()
    def on_edit_config(self):
        self.parent_window.toggle_edit_config()

    def set_text(self, text: str):
        key_map = {
            "Render Fps": "Render FPS",
            "Fps": "FPS",
            "Fov": "FOV",
        }
        allowed_keys = {
            "Render FPS",
            "Connected",
            "Network Rate",
            "Timesteps",
            "Ball Speed",
            "Ball Height",
        }
        cleaned_lines = []
        for raw_line in text.splitlines():
            line = raw_line.strip()
            if not line:
                continue

            lower_line = line.lower()
            if lower_line.startswith("camera:") or lower_line.startswith("view:") or "manual (" in lower_line:
                continue

            if ":" in line:
                key, value = line.split(":", 1)
                key = key.strip().replace("_", " ").title()
                key = key_map.get(key, key)
                if key not in allowed_keys:
                    continue
                line = f"{key}: {value.strip()}"
            else:
                continue

            cleaned_lines.append(line)

        self.text_label.setText("\n".join(cleaned_lines))

    def set_timesteps(self, total_timesteps: int, enabled: bool):
        self.parent_window.set_checkpoint_hud(total_timesteps, enabled)


def get_ui() -> QUIBarWidget:
    return _g_ui_widget


class QRSVWindow(QtWidgets.QMainWindow):
    def __init__(self, gl_widget):
        super().__init__()

        self.setWindowTitle("RocketSimVis")

        path = Path(__file__).parent.resolve() / "qt_style_sheet.css"
        self.setStyleSheet(path.read_text())

        self.gl_widget = gl_widget
        self.setCentralWidget(self.gl_widget)

        self.bar_widget = QUIBarWidget(self)
        self.bar_widget.setParent(self)
        self.bar_widget.raise_()

        self.timesteps_widget = QtWidgets.QFrame(self)
        self.timesteps_widget.setObjectName("HudContainer")
        self.timesteps_widget.setAttribute(Qt.WA_StyledBackground)
        self.timesteps_widget.setAutoFillBackground(True)
        self.timesteps_widget.setFixedWidth(round(300 * get_scaling_factor()))
        self.timesteps_widget.setAttribute(Qt.WA_OpaquePaintEvent, True)
        self.timesteps_widget.setStyleSheet(
            "QFrame#HudContainer {"
            "background-color: rgba(4, 8, 14, 235);"
            "border: 1px solid rgba(222, 188, 52, 0.80);"
            "border-radius: 7px;"
            "}"
        )
        t_layout = QtWidgets.QVBoxLayout(self.timesteps_widget)
        t_layout.setContentsMargins(8, 6, 8, 6)
        t_layout.setSpacing(2)
        self.timesteps_title = QtWidgets.QLabel("Checkpoints")
        self.timesteps_title.setObjectName("PanelTitle")
        self.timesteps_title.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        t_layout.addWidget(self.timesteps_title)
        self.timesteps_label = QtWidgets.QLabel("Current Checkpoint: N/A\nLatest Checkpoint: N/A")
        self.timesteps_label.setObjectName("HudText")
        self.timesteps_label.setWordWrap(False)
        self.timesteps_label.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        t_layout.addWidget(self.timesteps_label)
        self.timesteps_widget.hide()
        self.timesteps_widget.raise_()
        self._checkpoint_dir = None
        self._checkpoint_last_scan_time = 0.0
        self._checkpoint_last_value = None
        self._current_checkpoint_value = None
        self._startup_checkpoint_value = None
        self._checkpoint_last_text = ""
        self._startup_checkpoint_value = self._get_latest_checkpoint_step()

        self.edit_config_widget = QEditConfigWidget(self.gl_widget.config, self)
        self.edit_config_widget.setParent(self)
        self.edit_config_widget.hide()
        self.edit_config_widget.raise_()

        self.resize(WINDOW_SIZE_X, WINDOW_SIZE_Y)
        self._layout_overlay()

        self.installEventFilter(self)
        self.centralWidget().installEventFilter(self)
        self.home_timer = QTimer(self)
        self.home_timer.timeout.connect(self.update_home_snapshot)
        self.home_timer.start(250)

    def _layout_overlay(self):
        s = get_scaling_factor()
        margin = round(10 * s)
        target_hud_w = round(280 * s)
        self.bar_widget.setMaximumWidth(target_hud_w)
        self.bar_widget.setMinimumWidth(target_hud_w)
        self.bar_widget.setFixedWidth(target_hud_w)
        self.bar_widget.adjustSize()
        hud_w = target_hud_w
        hud_h = self.bar_widget.sizeHint().height()
        self.bar_widget.setGeometry(margin, margin, hud_w, hud_h)

        self.timesteps_widget.adjustSize()
        ts_w = max(round(300 * s), self.timesteps_widget.sizeHint().width())
        ts_h = self.timesteps_widget.sizeHint().height()
        self.timesteps_widget.setGeometry(
            max(margin, self.width() - margin - ts_w),
            margin,
            ts_w,
            ts_h,
        )

        panel_w = min(round(560 * s), self.width() - margin * 2)
        self.edit_config_widget.setFixedWidth(panel_w)
        self.edit_config_widget.adjustSize()
        desired_panel_h = self.edit_config_widget.sizeHint().height() + round(44 * s)
        panel_h = min(desired_panel_h, self.height() - (hud_h + margin * 3))
        self.edit_config_widget.setGeometry(
            margin,
            margin + hud_h + margin,
            panel_w,
            panel_h,
        )

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._layout_overlay()

    def eventFilter(self, obj, event):
        if event.type() == QEvent.KeyPress:
            # In freecam, route keys to GL widget only (prevents UI controls from reacting to Space, etc.).
            if self.gl_widget.camera_mode == 2:
                self.gl_widget.keyPressEvent(event)
                return True
            if event.key() == Qt.Key_Space:
                self.gl_widget.keyPressEvent(event)
                return True
            self.gl_widget.keyPressEvent(event)

        return super().eventFilter(obj, event)

    def toggle_edit_config(self):
        if self.edit_config_widget.isVisible():
            self.edit_config_widget.hide()
        else:
            self.edit_config_widget.show()
            self.edit_config_widget.raise_()

    def reset_camera_from_ui(self):
        self.gl_widget.reset_camera_to_default()

    def reset_camera_settings_to_default(self):
        self.gl_widget.config.reset_camera_defaults()
        self.edit_config_widget.refresh_visuals_color_rows()
        self.update()

    def refresh_ui_from_home(self):
        path = Path(__file__).parent.resolve() / "qt_style_sheet.css"
        self.setStyleSheet(path.read_text())
        self._layout_overlay()
        self.update()

    def set_auto_cycle_from_ui(self, enabled: bool):
        self.gl_widget.set_auto_cycle_enabled(enabled)

    def reset_visuals_to_default(self):
        cfg = self.gl_widget.config

        # Requested behavior: team tint enabled, boost colors enabled.
        cfg.enable_team_tint = True
        cfg.enable_boost_colors = True

        # Project default visual colors.
        cfg.team_blue_color_rgb = [165, 104, 154]
        cfg.team_orange_color_rgb = [119, 168, 112]
        cfg.boost_trail_color_rgb = [255, 230, 102]
        cfg.boost_pad_color_rgb = [255, 230, 102]

        self.edit_config_widget.refresh_visuals_color_rows()
        self.edit_config_widget.update()

    def set_show_timesteps_in_hud(self, enabled: bool):
        self.gl_widget.config.show_timesteps_in_hud = bool(enabled)
        if not enabled:
            self.timesteps_widget.hide()

    def set_checkpoint_hud(self, total_timesteps: int, enabled: bool):
        if not enabled:
            self.timesteps_widget.hide()
            return

        latest_checkpoint = self._get_latest_checkpoint_step()
        current_checkpoint = int(total_timesteps) if total_timesteps and total_timesteps > 0 else None

        if current_checkpoint is not None:
            self._current_checkpoint_value = current_checkpoint
        elif self._current_checkpoint_value is None and self._startup_checkpoint_value is not None:
            self._current_checkpoint_value = self._startup_checkpoint_value

        current_txt = f"{int(self._current_checkpoint_value):,}" if self._current_checkpoint_value is not None else "N/A"
        latest_txt = f"{int(latest_checkpoint):,}" if latest_checkpoint is not None else "N/A"
        new_text = (
            f"Current Checkpoint: {current_txt}\n"
            f"Latest Checkpoint: {latest_txt}"
        )
        if new_text != self._checkpoint_last_text:
            self.timesteps_label.setText(new_text)
            self._checkpoint_last_text = new_text
        self.timesteps_widget.show()
        self.timesteps_widget.raise_()

    def _find_checkpoint_dir(self):
        candidates = []
        try:
            candidates.append(Path.cwd().resolve())
        except Exception:
            pass
        try:
            candidates.append(Path(__file__).resolve().parent)
        except Exception:
            pass
        try:
            candidates.append(Path(sys.argv[0]).resolve().parent)
        except Exception:
            pass

        checked = set()
        for base in candidates:
            for root in [base, *base.parents]:
                if root in checked:
                    continue
                checked.add(root)
                cp = root / "checkpoints"
                if cp.is_dir():
                    return cp
            # Also probe common build output folder patterns under this base.
            for pattern in ("out/build/*/checkpoints", "build/*/checkpoints", "*/checkpoints"):
                try:
                    for cp in base.glob(pattern):
                        if cp.is_dir():
                            return cp
                except Exception:
                    pass
        return None

    def _get_latest_checkpoint_step(self):
        now = time.time()
        if (now - self._checkpoint_last_scan_time) < 1.0:
            return self._checkpoint_last_value
        self._checkpoint_last_scan_time = now

        if self._checkpoint_dir is None or not self._checkpoint_dir.is_dir():
            self._checkpoint_dir = self._find_checkpoint_dir()
        if self._checkpoint_dir is None:
            self._checkpoint_last_value = None
            return None

        latest = None
        try:
            for child in self._checkpoint_dir.iterdir():
                if child.is_dir() and child.name.isdigit():
                    val = int(child.name)
                    if latest is None or val > latest:
                        latest = val
        except Exception:
            latest = None

        self._checkpoint_last_value = latest
        return latest

    def reset_ball_prediction_to_default(self):
        self.gl_widget.config.reset_ball_prediction_defaults()
        self.edit_config_widget.refresh_visuals_color_rows()
        self.edit_config_widget.update()

    def update_home_snapshot(self):
        snapshot = self.gl_widget.get_camera_snapshot()
        self.edit_config_widget.set_home_snapshot(snapshot)
