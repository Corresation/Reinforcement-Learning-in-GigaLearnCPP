# TODO: Having them hardcoded in strings kinda sucks for editing complex shaders

FRAG_SHADER = '''
#version 330

// RGB to HSV conversion
vec3 rgb2hsv(vec3 c)
{
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));

    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}

// HSV to RGB conversion
vec3 hsv2rgb(vec3 c)
{
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

uniform sampler2D Texture;
uniform vec3 cameraPos;
uniform vec3 ballPos;
uniform vec4 globalColor;
uniform int enableTeamTint;
uniform vec3 blueTeamColor;
uniform vec3 orangeTeamColor;
uniform int selectiveTintEnabled;
uniform vec3 selectiveTintColor;

in FD {
    vec3 vert;
    vec3 norm;
    vec2 text;
} inData;

out vec4 f_color;

void main() { 
    vec4 vertColor = texture(Texture, inData.text);

    // Selective texture tinting: recolor only yellow-ish regions (used for boost pads).
    if (selectiveTintEnabled == 1) {
        vec3 hsvSel = rgb2hsv(vertColor.rgb);
        bool isYellow = (hsvSel.x > 0.10 && hsvSel.x < 0.20) && hsvSel.y > 0.25 && hsvSel.z > 0.20;
        if (isYellow) {
            vec3 tintHSV = rgb2hsv(selectiveTintColor);
            vec3 remapHSV = vec3(tintHSV.x, clamp(max(hsvSel.y, tintHSV.y * 0.6), 0.0, 1.0), hsvSel.z);
            vertColor.rgb = hsv2rgb(remapHSV);
        }
    }
    
    // Preserve boost glow and transparent effects
    if (vertColor.a < 0.95) {
        f_color = vertColor;
        if (globalColor != vec4(0,0,0,0))
            f_color = globalColor;
        return;
    }
    
    vec3 normal = normalize(inData.norm);
    vec3 viewDir = normalize(cameraPos - inData.vert);
    
    // Realistic stadium lighting from above
    vec3 sunLightDir = normalize(vec3(0.3, -0.2, 0.85));  // From above at angle
    vec3 sunLightColor = vec3(1.0, 0.98, 0.96);  // Neutral white with slight warmth

    vec3 ambientLightColor = vec3(0.35, 0.35, 0.35);  // Neutral gray, brighter

    // Diffuse lighting
    float sunDiffuse = max(dot(normal, sunLightDir), 0.0);

    // Subtle specular
    vec3 halfwayDir = normalize(sunLightDir + viewDir);
    float specular = pow(max(dot(normal, halfwayDir), 0.0), 64.0);

    // Gentle fresnel
    float fresnel = pow(1.0 - max(dot(viewDir, normal), 0.0), 3.0);

    // Material detection
    vec3 hsv = rgb2hsv(vertColor.rgb);
    if (enableTeamTint == 1 && hsv.y > 0.35 && hsv.z > 0.20) {
        bool isBluePaint = hsv.x > 0.52 && hsv.x < 0.72;
        bool isOrangePaint = hsv.x < 0.14 || hsv.x > 0.95;
        if (isBluePaint || isOrangePaint) {
            vec3 targetCol = isBluePaint ? blueTeamColor : orangeTeamColor;
            vec3 targetHSV = rgb2hsv(targetCol);
            float sat = mix(hsv.y, targetHSV.y, 0.55);
            float val = hsv.z * 0.88;
            vec3 remapHSV = vec3(targetHSV.x, clamp(sat, 0.0, 1.0), clamp(val, 0.0, 1.0));
            vec3 remapped = hsv2rgb(remapHSV);
            vertColor.rgb = mix(vertColor.rgb, remapped, 0.78);
            hsv = rgb2hsv(vertColor.rgb);
        }
    }
    float metallic = (hsv.y > 0.7 && hsv.z > 0.5) ? 0.6 : 0.1;

    // Combine lighting - stronger diffuse, neutral colors
    vec3 diffuse = vertColor.rgb * (sunLightColor * sunDiffuse * 1.0 + ambientLightColor);
    vec3 highlight = sunLightColor * (specular * 0.05 + fresnel * 0.02) * (1.0 + metallic);

    vec3 finalColor = diffuse + highlight;
    
    // Vibrant color preservation
    bool isVibrantColor = hsv[1] > 0.7;
    if (isVibrantColor) {
        float vibrantScale = 0.15;
        finalColor = finalColor * (1.0 - vibrantScale) + vertColor.rgb * vibrantScale;
    }
    
    // Clamp to prevent overexposure
    finalColor = clamp(finalColor, vec3(0.0), vec3(1.0));
    
    f_color = vec4(finalColor, vertColor.a);
    
    // Override with global color if set
    if (globalColor != vec4(0,0,0,0))
        f_color = globalColor;
}
'''

VERT_SHADER = '''
#version 330

uniform mat4 m_vp;
uniform mat4 m_model;

in vec3 in_position;
in vec4 in_normal;
in vec2 in_texcoord_0;

out FD {
    vec3 vert;
    vec3 norm;
    vec2 text;
} outData;

noperspective out vec2 windowPosition;

void main() {
    outData.vert = in_position;
    
    mat4 modelRot = m_model;
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 4; j++)
            if (i == 3 || j == 3)
                modelRot[i][j] = (i == j) ? 1 : 0;
    
    outData.norm = (modelRot * in_normal).xyz;
    outData.text = in_texcoord_0;
    gl_Position = m_vp * m_model * vec4(in_position, 1.0);
    windowPosition = in_position.xy;
}
'''
